# local
#MONGO_HOST='localhost'
#MONGO_DBNAME='du2x'

# linode
#MONGO_HOST='23.92.26.126'
#MONGO_DBNAME='du2x'

# mlab
#MONGO_HOST='ds043358.mlab.com'
#MONGO_PORT=43358
#MONGO_USERNAME='ada'
#MONGO_PASSWORD='chuvinha10'
#MONGO_DBNAME='ubiqs'
MONGO_URI='mongodb://sidicrei:s3r7p3@ds251277.mlab.com:51277/mongo'
